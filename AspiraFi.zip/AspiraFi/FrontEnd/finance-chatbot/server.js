const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

const OPENAI_API_KEY = "sk-proj-G2GJSKmNqk6GIKVp7-NxmfkV1kCOjGMsgzw0I8ov3OI1tUmqW82kGqpdqvort7oNsL554Jj2KGT3BlbkFJHR5EO4i9hZROqpkhuNw5XS-O9_Odg66QjfMLwiKCCBChXHylNnlaCXMouH0H9x6h84vl6WnfsAey"; // Replace with your API key

app.post('/chatbot', async (req, res) => {
    try {
        const userMessage = req.body.message;
        const response = await axios.post("https://api.openai.com/v1/chat/completions", {
            model: "gpt-4",
            messages: [{ role: "system", content: "You are a finance and loan expert chatbot." }, { role: "user", content: userMessage }]
        }, {
            headers: { "Authorization": `Bearer ${OPENAI_API_KEY}` }
        });

        res.json({ reply: response.data.choices[0].message.content });
    } catch (error) {
        res.status(500).json({ error: "Error fetching response" });
    }
});

app.listen(5000, () => console.log("Server running on port 5000"));
